package com.sl.spring.mvcdemo.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class HelloWorldController {
	// the url is http://localhost:8080/SpringMVCDemo/helloWorld
	@RequestMapping("/helloWorld")
	public String sayHello() {
		return "hello";
	}
	
	@RequestMapping("/greet")
	public String greet() {
		return "greeting";
	}
	
	// the url is http://localhost:8080/SpringMVCDemo/greetuser/nisha
	// the url is http://localhost:8080/SpringMVCDemo/greetuser/Asha
	@RequestMapping("/greetuser/{name}")
	public ModelAndView greetUser(@PathVariable("name") String uname) {
		ModelAndView view = new ModelAndView("greetUser");
		view.addObject("msg", uname);		
		return view;
	}

}
