package com.springdemo2.client;

import com.springdemo2.beans.Address;
import com.springdemo2.beans.Employee;
import com.springdemo2.beans.Person;

public class Demo {

	public static void main(String[] args) {
		Address address = new Address();
		System.out.println(address);
		address.setCity("Pune");
		address.setZipcode("12345");
		System.out.println(address);
		
		Employee employee = new Employee();
		System.out.println(employee);
		employee.setEmpId(1234);
		employee.setEmpName("Nisha");
		employee.setAddress(address); // setter injection
		System.out.println(employee);
		
		Person person = new Person("Ramlal", address); // constructor injection
		System.out.println(person);
	}

}
