package com.springdemo2.client;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.springdemo2.beans.Address;
import com.springdemo2.beans.HelloWorld;
import com.springdemo2.beans.Student;

public class Client {
	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext("beans.xml");
		HelloWorld obj1 = (HelloWorld) context.getBean("helloWorld");
		// returns an object of Object class which further 
		// needs to be down casted in required class type
		System.out.println(obj1.greetUser());
		
		HelloWorld obj2 = context.getBean(HelloWorld.class);
		// returns an object of required class where down casting is taken care of internally
		System.out.println(obj2.greetUser());
		
		Address address = (Address) context.getBean("addr1");
		System.out.println(address);
		
		Student student1 = (Student) context.getBean("student1");
		System.out.println(student1);
		
		Student student2 = (Student) context.getBean("student2");
		System.out.println(student2);
		
	}
}
