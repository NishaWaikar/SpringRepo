package com.springdemo2.beans;


public class HelloWorld {
	private String userName;
	
	public HelloWorld() {
		System.out.println("Constructor");
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}
	
	public String greetUser() {
		return "Hello " + userName;
	}
}
