package com.springdemo3.client;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.springdemo3.config.SpringJdbcConfig;
import com.springdemo3.dao.EmployeeDao;
import com.springdemo3.dao.EmployeeDaoImpl;
import com.springdemo3.dto.Employee;

public class Client {
	public static void main(String[] args) {
		ApplicationContext context = new AnnotationConfigApplicationContext(SpringJdbcConfig.class);
		
		EmployeeDao dao = context.getBean(EmployeeDaoImpl.class);
		
		Employee employee = new Employee(2, "Shamlal", "Developer");
		
		boolean isEmpAdded = dao.addEmployee(employee);
		if(isEmpAdded == true)
			System.out.println("Employee added successfully");
		else 
			System.out.println("Employee not added");
		
		boolean isEmpUpdated = dao.updateEmployee(1, "Sr. Developer");
		if(isEmpUpdated == true)
			System.out.println("Employee updated successfully");
		else 
			System.out.println("Employee not updated");
	}
}
