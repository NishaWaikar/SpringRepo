package com.springdemo3.dao;

import java.util.Set;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.springdemo3.dto.Employee;

@Component
public class EmployeeDaoImpl implements EmployeeDao{
	private JdbcTemplate jdbcTemplate; // required to perform operations on the database
	// JdbcTemplate needs to know the details of database
	
	@Autowired
	public EmployeeDaoImpl(DataSource dataSource) {
		jdbcTemplate = new JdbcTemplate(dataSource);
	}
	@Override
	public boolean addEmployee(Employee employee) {
		boolean isEmployeeAdded = false;
		
		String query = "insert into employees values(?,?,?)";
		int val = jdbcTemplate.update(query, employee.getEmpId(), employee.getEmpName(), employee.getDesignation());
		if(val > 0)
			isEmployeeAdded = true;
		
		return isEmployeeAdded;
	}

	@Override
	public boolean updateEmployee(int empId, String designation) {
		boolean isEmployeeUpdated = false;
		
		String query = "update employees set designation = ? where empid = ?";
		int val = jdbcTemplate.update(query, designation, empId);
		if(val > 0)
			isEmployeeUpdated = true;
		
		return isEmployeeUpdated;
	}

	@Override
	public boolean deleteEmplyee(int empId) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Employee searchEmployee(int empId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Set<Employee> getAllEmployees() {
		// TODO Auto-generated method stub
		return null;
	}

}
