package com.springdemo3.dao;

import java.util.Set;

import com.springdemo3.dto.Employee;

public interface EmployeeDao {
	public boolean addEmployee(Employee employee);
	public boolean updateEmployee(int empId, String designation);
	public boolean deleteEmplyee(int empId);
	public Employee searchEmployee(int empId);
	public Set<Employee> getAllEmployees();
}
