package com.simplilearn.trg.spring.springmvcannotations.dao;

import org.springframework.stereotype.Repository;

import com.simplilearn.trg.spring.springmvcannotations.model.Student;

@Repository
public class StudentDaoImpl implements StudentDao {

	@Override
	public boolean validateStudent(String rollNo, String password) {
		boolean isStudentValid = false;
		
		if(rollNo.equals("123") && password.equals("abc123"))
			isStudentValid = true;
		
		System.out.println("isStudentValid: " + isStudentValid);
		return isStudentValid;
	}

	@Override
	public boolean registerStudent(Student student) {
		System.out.println(student);
		return true;
	}

}
