package com.simplilearn.trg.spring.springmvcannotations.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.simplilearn.trg.spring.springmvcannotations.dao.StudentDao;
import com.simplilearn.trg.spring.springmvcannotations.model.Student;


@Service
public class StudentServiceImpl implements StudentService{
	@Autowired
	private StudentDao studentDao;
	
	
	@Override
	public boolean validateStudent(String rollNo, String password) {
		return studentDao.validateStudent(rollNo, password);
	}


	@Override
	public boolean registerStudent(Student student) {
		return studentDao.registerStudent(student);
	}

}
