package com.simplilearn.trg.spring.springmvcannotations.controllers;

import org.springframework.stereotype.Controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class WelcomUserController {
	
	@RequestMapping("/input")
	public String displayInputPage() {
		return "input";
	}
	
	@RequestMapping("/greet")
	public ModelAndView welcomeUser(@RequestParam("uname") String userName) {
		ModelAndView view = new ModelAndView("welcomeuser");
		view.addObject("name", userName);
		return view;
	}
}
