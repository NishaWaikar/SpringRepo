package com.simplilearn.trg.spring.springmvcannotations.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import com.simplilearn.trg.spring.springmvcannotations.model.HelloWorld;

@Controller
public class HelloWorldController {
	
	@RequestMapping("/helloworld")
	public String sayHelloWorld(Model model) {
		HelloWorld helloWorld = new HelloWorld();
		helloWorld.setMessage("Welcome to Spring MVC using Annotations");
		model.addAttribute("helloWorld", helloWorld);
		return "helloworld";
	}
	
	@RequestMapping("/hello")
	public String sayHello() {
		return "Hello";
	}
}
