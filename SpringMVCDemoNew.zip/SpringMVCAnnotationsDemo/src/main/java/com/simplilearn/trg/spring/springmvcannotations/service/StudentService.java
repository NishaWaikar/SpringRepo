package com.simplilearn.trg.spring.springmvcannotations.service;

import com.simplilearn.trg.spring.springmvcannotations.model.Student;

public interface StudentService {
	public boolean validateStudent(String rollNo, String password);
	public boolean registerStudent(Student student);
}
