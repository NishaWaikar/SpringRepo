package com.simplilearn.trg.spring.springmvcannotations.dao;

import org.springframework.stereotype.Repository;

import com.simplilearn.trg.spring.springmvcannotations.model.Student;

@Repository
public interface StudentDao {
	public boolean validateStudent(String rollNo, String password);
	public boolean registerStudent(Student student);
}
