package com.simplilearn.trg.spring.springmvcannotations.model;

public class Student {
	private String rollNo;
	private String firstName;
	private String lastName;
	private String password;
	
	public Student() {
		System.out.println("Student constructor");
	}

	public String getRollNo() {
		return rollNo;
	}

	public void setRollNo(String rollNo) {
		System.out.println("setRollNo");
		this.rollNo = rollNo;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		System.out.println("setFirstName");
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		System.out.println("setLastName");
		this.lastName = lastName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		System.out.println("setPassword");
		this.password = password;
	}

	@Override
	public String toString() {
		return "Student [rollNo=" + rollNo + ", firstName=" + firstName + ", lastName=" + lastName + ", password="
				+ password + "]";
	}
	
}
