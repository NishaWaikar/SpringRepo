package com.simplilearn.trg.spring.springmvcannotations.controllers;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import com.simplilearn.trg.spring.springmvcannotations.model.User;

@Controller
public class UserController {
	private Set<User> allUsers;
	
	public UserController() {
		allUsers = new HashSet<User>();
		allUsers.add(new User("1", "Ramlal"));
		allUsers.add(new User("2", "Shamlal"));
		allUsers.add(new User("3", "Seeta"));
		allUsers.add(new User("4", "Geeta"));
	}
	
	@RequestMapping("/getUser/{userId}")
	public String getUser(@PathVariable("userId") String userId, Model model) {
		User aUser = null;
		for (User user : allUsers) {
			if(user.getUserId().equals(userId)) {
				aUser = user;
				break;
			}
		}
		model.addAttribute("aUser", aUser);
		return "displayUserName";
	}
	
	@RequestMapping("/getUserDetails/{userId}/{userName}")
	public String getUserDetails(@PathVariable("userId") String userId, @PathVariable("userName") String userName, Model model) {
		User aUser = null;
		for (User user : allUsers) {
			if(user.getUserId().equals(userId) && user.getUserName().equals(userName)) {
				aUser = user;
				break;
			}
		}
		model.addAttribute("aUser", aUser);
		return "userDetails";
	}
	
	@RequestMapping("/getUserInfo/{userId}/{userName}")
	public String getUserInfo(@PathVariable Map<String, String> pathVars, Model model) {
		Collection<String> vals = pathVars.values();
		
		ArrayList<String> allVals = new ArrayList<String>(vals);
		System.out.println(allVals);
		String userId = allVals.get(0);
		String userName = allVals.get(1);
		
		User aUser = null;
		for (User user : allUsers) {
			if(user.getUserId().equals(userId) && user.getUserName().equals(userName)) {
				aUser = user;
				break;
			}
		}
		model.addAttribute("aUser", aUser);
		
		
		return "userInfo";
	}
}







