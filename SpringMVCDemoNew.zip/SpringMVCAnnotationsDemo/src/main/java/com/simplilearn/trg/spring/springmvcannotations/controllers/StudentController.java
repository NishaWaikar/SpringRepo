package com.simplilearn.trg.spring.springmvcannotations.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.simplilearn.trg.spring.springmvcannotations.model.Student;
import com.simplilearn.trg.spring.springmvcannotations.service.StudentService;
import com.simplilearn.trg.spring.springmvcannotations.service.StudentServiceImpl;

@Controller
public class StudentController {
	@Autowired
	private StudentService studentService;
	
//	public StudentController() {
//		studentService = new StudentServiceImpl();
//	}
	
	@RequestMapping("/login")
	public String getLoginPage() {
		return "login";
	}
	
	@RequestMapping(value = "/validatestudent", method=RequestMethod.POST)
	public ModelAndView validateStudent(@RequestParam("rollno") String rollNo, @RequestParam("password") String password) {
		String viewName = null;
		boolean isStudentValid = studentService.validateStudent(rollNo, password);
		System.out.println("In controller : " + rollNo + " : " + password);
		if(isStudentValid)
			viewName = "validstudent";
		else
			viewName = "invalidstudent";
			
			
		ModelAndView modelAndView = new ModelAndView(viewName);
		return modelAndView;
	}
	
	@RequestMapping("/register")
	public String getStudentRegisterPage() {
		return "register";
	}
	
	@RequestMapping(value="/addstudent" , method = RequestMethod.POST)
	public String registerStudent(@ModelAttribute("student") Student student, BindingResult result) {
		String viewName = null;
		boolean isStudentRegistered = studentService.registerStudent(student);
		if(isStudentRegistered)
			viewName = "registersuccess";
		else
			viewName = "registerfailure";
		return viewName;
	}
}














