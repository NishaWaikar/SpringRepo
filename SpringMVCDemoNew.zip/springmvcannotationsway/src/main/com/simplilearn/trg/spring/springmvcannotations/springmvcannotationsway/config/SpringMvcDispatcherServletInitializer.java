package com.simplilearn.trg.spring.springmvcannotations.springmvcannotationsway.config;

public class SpringMvcDispatcherServletInitializer {

}
