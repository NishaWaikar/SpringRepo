package com.simplilearn.trg.spring.springmvcannotations.springmvcannotationsway.controller;

public class HelloController {

}
