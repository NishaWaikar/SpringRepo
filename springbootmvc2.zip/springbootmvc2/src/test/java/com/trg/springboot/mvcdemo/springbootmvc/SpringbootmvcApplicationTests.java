package com.trg.springboot.mvcdemo.springbootmvc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootmvcApplicationTests {

	@Test
	void contextLoads() {
	}

}
