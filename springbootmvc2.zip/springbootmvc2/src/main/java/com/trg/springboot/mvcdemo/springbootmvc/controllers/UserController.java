package com.trg.springboot.mvcdemo.springbootmvc.controllers;



import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.trg.springboot.mvcdemo.springbootmvc.dto.User;
import com.trg.springboot.mvcdemo.springbootmvc.service.UserServiceImpl;



@RestController
public class UserController {
	
	@Autowired
	private UserServiceImpl serviceImpl;
	
	@RequestMapping("/getusers")
	public ModelAndView getUsers(){
		List<User> users = serviceImpl.getAllUsers();
		ModelAndView view = new ModelAndView("users");
		view.addObject("allusers", users);
		return view;
	}
	
	@RequestMapping("/addUser")
	public ModelAndView getAddUserPage() {
		ModelAndView view = new ModelAndView("addUser");
		return view;
	}
	
	@PostMapping("/addUser")
	public ModelAndView addUser(@ModelAttribute("user") User user) {
		ModelAndView view = new ModelAndView("success");
		view.addObject("newUser", user);
		return view;
	}
}
