package com.trg.springboot.mvcdemo.springbootmvc.dao;

import java.util.List;

import com.trg.springboot.mvcdemo.springbootmvc.dto.User;

public interface UserDao {
	public List<User> getAllUsers();
}
