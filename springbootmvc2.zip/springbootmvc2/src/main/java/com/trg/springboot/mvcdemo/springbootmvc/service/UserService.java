package com.trg.springboot.mvcdemo.springbootmvc.service;

import java.util.List;

import com.trg.springboot.mvcdemo.springbootmvc.dto.User;

public interface UserService {
	public List<User> getAllUsers();
}
