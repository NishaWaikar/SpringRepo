package com.trg.springboot.mvcdemo.springbootmvc.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.trg.springboot.mvcdemo.springbootmvc.dto.User;

@Repository
public class UserDaoImpl implements UserDao{

	@Override
	public List<User> getAllUsers() {
		List<User> allUsers = new ArrayList<>();
		allUsers.add(new User("user1", "pwd1"));
		allUsers.add(new User("user2", "pwd2"));
		allUsers.add(new User("user3", "pwd3"));
		
		return allUsers;
	}

}
