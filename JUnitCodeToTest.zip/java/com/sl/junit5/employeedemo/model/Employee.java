package com.sl.junit5.employeedemo.model;

public class Employee {
	private int employeeId;
	private String firstName;
	private String lastName;
	private String phoneNumber;

	public Employee(int employeeId, String firstName, String lastName, String phoneNumber) {
		this.employeeId = employeeId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.phoneNumber = phoneNumber;
	}

	public int getEmployeeId() {
		return employeeId;
	}
	

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public String getFirstName() {
		return firstName;
	}

	public String getLastName() {
		return lastName;
	}

}
