package com.sl.junit5.employeedemo.service;

import java.util.ArrayList;
import java.util.List;

import com.sl.junit5.employeedemo.exception.EmployeeDoesNotExistsException;
import com.sl.junit5.employeedemo.model.Employee;
import com.sl.junit5.employeedemo.util.ValidationUtil;

public class EmployeeService {

    private List<Employee> employees = new ArrayList<>();

    public void addEmployee(int employeeId, String firstName, String lastName, String phoneNumber) {
        Employee employee = new Employee(employeeId, firstName, lastName, phoneNumber);
        if(validateEmployee(employee) && checkIfContactAlreadyExist(employee))
        employees.add(employee);
    }

    public List<Employee> getEmplpoyees() {
        return employees;
    }

    private boolean checkIfContactAlreadyExist(Employee employee) {
        if (employees.contains(employee))
            throw new RuntimeException("Employee Already Exists");
        else
        	return true;
    }

    private boolean validateEmployee(Employee employee) {
       ValidationUtil.validateFirstName(employee.getFirstName());
       ValidationUtil.validateLastName(employee.getLastName());
       ValidationUtil.validatePhoneNumber(employee.getPhoneNumber());
       return true;
    }

    public Employee getEmployeeById(int employeeId) {
		for(Employee employee : employees) {
			if(employeeId==employee.getEmployeeId()) {
				return employee;
			}
		}
		return null;
	}
    
    public Integer[] getEmployeeIdsByFirstName(String firstName) {
		List<Integer> employeeIds = new ArrayList<>();
		for(Employee employee : employees) {
			if(firstName.equals(employee.getFirstName())) {
				employeeIds.add(employee.getEmployeeId());
			}
		}
		return employeeIds.toArray(new Integer[employeeIds.size()]);
	}
    
    public List<String> getPhoneNumbersByFirstName(String firstName) {
		List<String> phoneNumbers = new ArrayList<>();
		for(Employee employee : employees) {
			if(firstName.equals(employee.getFirstName())) {
				phoneNumbers.add(employee.getPhoneNumber());
			}
		}
		return phoneNumbers;
	}
    
    public Employee getEmployeeByPhoneNumber(String phoneNumber) {
		for(Employee employee : employees) {
			if(phoneNumber.equals(employee.getPhoneNumber())) {
				return employee;
			}
		}
		throw new EmployeeDoesNotExistsException("Employee Does not Exists!");
	}
	
   
}

