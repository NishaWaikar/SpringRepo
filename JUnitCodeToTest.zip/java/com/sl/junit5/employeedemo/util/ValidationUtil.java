package com.sl.junit5.employeedemo.util;

public class ValidationUtil {
	
	public static boolean validateFirstName(String firstName) {
		if (firstName.isBlank())
			throw new RuntimeException("First Name Cannot be null or empty");
		else
			return true;
	}

	public static boolean validateLastName(String lastName) {
		if (lastName.isBlank())
			throw new RuntimeException("Last Name Cannot be null or empty");
		else
			return true;
	}

	public static boolean validatePhoneNumber(String phoneNumber) {
		if (phoneNumber.isBlank()) {
			throw new RuntimeException("Phone Name Cannot be null or empty");
		}

		if (phoneNumber.length() != 10) {
			throw new RuntimeException("Phone Number Should be 10 Digits Long");
		}
		if (!phoneNumber.matches("\\d+")) {
			throw new RuntimeException("Phone Number Contain only digits");
		}
		if (!phoneNumber.startsWith("0")) {
			throw new RuntimeException("Phone Number Should Start with 0");
		} else
			return true;
	}

}
