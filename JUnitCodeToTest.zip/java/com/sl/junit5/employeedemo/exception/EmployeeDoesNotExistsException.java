package com.sl.junit5.employeedemo.exception;

public class EmployeeDoesNotExistsException extends RuntimeException {

	private static final long serialVersionUID = 5937598642748122459L;

	public EmployeeDoesNotExistsException(String message) {
		super(message);
	}
}
